# -*- coding: utf-8 -*-
"""
Created on Wed May 18 07:48:46 2022

@author: adminzhaoqian
"""

# import pandas as pd
# import matplotlib.pyplot as plyt
# import plotly.express as px

# def simple1(dict1={'redemand':[], 'reorder': [], 'relots': [], 'reprice': []}):
#     fig = px.bar(dict1, x=)