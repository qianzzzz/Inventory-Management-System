# -*- coding: utf-8 -*-
"""
Created on Wed May 18 07:48:46 2022

@author: adminzhaoqian
"""
import os, sys
from docplex.cp.model import *
import cplex

class Test():
    def __init__(self, x):
        self.x = x
        
def inventoryDefault(lotSize=20, 
                     holdingCost=1,
                     fixCost=500,
                     demand=[37, 45, 88, 41, 75, 123, 72],
                     initInv=[7, 0, 6, 0],
                     unitCost=4,
                     initPrice=10,
                     elastPD=1.0, ):
    
    ret = {'demand': [],
           'order': [],
           'lots': [],
           'price': [],
           'date': [],
           'shelfLife': [],
           'horizons': [],
           'preint': [],
          'postint': [],
          'closeInv': [],}
    
    try:
    
        horizon = len(demand)
        shelfLife = len(initInv)
    
    
        horizons = range(0, horizon)
        shelfLifes = range(0, shelfLife)
    
        keysPreInv = [(i, j) for i in horizons for j in shelfLifes]
    
        keysClostInv = [(i, j) for i in horizons for j in range(-1, shelfLife - 1)]
    
        # B: update the list issue
    
        price = integer_var_list(horizon, unitCost, initPrice, 'price')
        order = integer_var_list(horizon, 0, 1, 'order')
        lots = integer_var_list(horizon, 0, name='lots')
        preInv = integer_var_dict(keysPreInv, 0, name='preinv')
        postInv = integer_var_dict(keysPreInv, 0, name='postinv')
        closeInv = integer_var_dict(keysClostInv, 0, name='closeinv')
        inducedDemand = integer_var_list(horizon, 0, name='inducedDemand')
        alpha = integer_var_dict(keysPreInv, 0, 1, name='soldAlpha')
        beta = integer_var_dict(keysPreInv, 0, 1, name='soldBeta')
        profit = integer_var(name='profit')
    
        profit = sum(price[t] * inducedDemand[t] - 
                     fixCost * order[t] - 
                     holdingCost * sum(closeInv[t, n] for n in range(-1, shelfLife - 1)) - 
                     unitCost * lotSize * lots[t] for t in horizons)
    
        mdl = CpoModel(name="inventory")
        mdl.add(maximize(profit))
    
        # merge all the scatter for loops into one
        for t in horizons:
            demand[t] = int(demand[t])
           # elastic demand of price, for the discount price
            # with open('E:\InventoryManagementPlatform\debug.txt', 'w') as f:
            #    f.write(f'''indu{inducedDemand[t]}{type(inducedDemand[t])},
            #            demand{demand[t]}{type(demand[t])},
            #            elastPD{elastPD}{type(elastPD)},
            #            initPrice{initPrice}{type(initPrice)},
            #            ''')

            mdl.add(inducedDemand[t] == demand[t] + ceil(elastPD * demand[t] * (initPrice - price[t])))
            
            # the upper limit of everyday's inventory level
            mdl.add(lotSize * lots[t] <= sum(inducedDemand[i] for i in range(t, horizon)) * order[t])
            
            mdl.add(inducedDemand[t] <= sum(alpha[t, n] * postInv[t, n] for n in shelfLifes))
            mdl.add(inducedDemand[t] >= sum(beta[t, n] * postInv[t, n] for n in shelfLifes))
            mdl.add(sum(alpha[t, n] for n in shelfLifes) - sum(beta[t, n] for n in shelfLifes) == 1)
            
            mdl.add(postInv[t, shelfLife - 1] == lotSize * lots[t])
            
            mdl.add(sum(closeInv[t, n] for n in range(-1, shelfLife - 1)) == 
                    sum(postInv[t, n] for n in shelfLifes) -
                    inducedDemand[t])
            
            if t >= 1:
                mdl.add(preInv[t, shelfLife - 1] == 0)
    
            for n in shelfLifes:   
                initInv[n] = int(initInv[n])
                # set initial invetory in first planning day
                if t == 0:
                    mdl.add(preInv[t, n] == initInv[n])
            
                # except the freshest ones, postinv eqauls to preint
                if n < shelfLife - 1:
                    mdl.add(postInv[t, n] == preInv[t, n])
                    
                if (t < horizon - 1) and (n < shelfLife - 1):
                    mdl.add(closeInv[t, n] == preInv[t + 1, n])
                
                if (n < shelfLife - 1):
                    mdl.add(alpha[t, n] >= alpha[t, n + 1])
                    mdl.add(beta[t, n] >= beta[t, n + 1])
                
                mdl.add(closeInv[t, n - 1] >= (1 - alpha[t, n]) * postInv[t, n])
                mdl.add(closeInv[t, n - 1] <= (1 - beta[t, n]) * postInv[t, n])

        msol = mdl.solve(TimeLimit=60)
    
        redemand = []
        reorder = []
        relots = []
        reprice = []
        repreint = []
        repostinv = []
        realpha = []
        rebeta = []
        reclostinv = []
        redate = []
    
        for t in horizons:
            redate.append('day' + str(t + 1))
            redemand.append(msol[inducedDemand[t]])
            reorder.append(msol[order[t]])
            relots.append(msol[lots[t]])
            reprice.append(msol[price[t]])
            
            repreint.append([])
            repostinv.append([])
            realpha.append([])
            rebeta.append([])    
            reclostinv.append([])
            
            for n in shelfLifes:
                repreint[-1].append(msol[preInv[t, n]])
                repostinv[-1].append(msol[postInv[t, n]])
                realpha[-1].append(msol[alpha[t, n]])
                rebeta[-1].append(msol[beta[t, n]])
    
                reclostinv[-1].append(msol[closeInv[t, n - 1]])
        
        ret['demand'] = redemand
        ret['order'] = reorder
        ret['lots'] = relots
        ret['price'] = reprice
        ret['date'] = redate
        ret['horizons'] = horizons
        ret['shelfLife'] = shelfLife
        ret['preint'] = repreint
        ret['postint'] = repostinv
        ret['closeInv'] = reclostinv
        
        profit = sum(reprice[t] * redemand[t] - 
                     fixCost * reorder[t] - 
                     holdingCost * sum(reclostinv[t][ n - 1] for n in range(-1, shelfLife - 1)) - 
                     unitCost * lotSize * relots[t] for t in horizons)

        # profit = sum(ret1['price'][t] * ret1['demand'][t] - 
        #              fixCost * ret1['order'][t] - 
        #              holdingCost * sum(ret1['closeInv'][t][ n - 1] for n in range(-1, ret1['shelfLife'] - 1)) - 
        #              unitCost * lotSize * ret1['lots'][t] for t in ret1['horizons'])
        ret['profit'] = profit
        print(f'ret: {ret}')

        with open('E:\InventoryManagementPlatform\log1.txt', 'w') as f:
            f.write(str(ret))
    except Exception as exc:
        print(f' exc: {exc}')
        exc_type, exc_obj, exc_tb = sys.exc_info()
        with open('E:\InventoryManagementPlatform\log.txt', 'w') as f:
            f.write(str(exc))
            f.write(str(exc_tb.tb_lineno))
    
    return ret


# para.
# lotSize = 20
# holdingCost = 1
# fixCost = 500
# demand = [37, 45, 88]
# initInv = [7, 0]
# unitCost = 4
# initPrice = 10
# elastPD = 1.0
# ret1 = inventoryDefault()
# profit = sum(ret1['price'][t] * ret1['demand'][t] - 
#               fixCost * ret1['order'][t] - 
#               holdingCost * sum(ret1['closeInv'][t][ n - 1] for n in range(-1, ret1['shelfLife'] - 1)) - 
#               unitCost * lotSize * ret1['lots'][t] for t in ret1['horizons'])

# print('inducedDemand: ', ret1['demand'], '\n', 
#               'order: ', ret1['order'], '\n',
#               'lots: ', ret1['lots'], '\n',
#               'price: ', ret1['price'], '\n',
#               'profit: ', [ret1['profit']], '\n')
# print('preint: ', repreint)
# print('postInv: ', repostinv)
# print('alpha: ', realpha)
# print('beta: ', rebeta)
# print('closeInv: ', reclostinv)