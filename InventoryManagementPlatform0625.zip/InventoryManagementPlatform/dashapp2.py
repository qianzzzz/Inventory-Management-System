# -*- coding: utf-8 -*-
"""
Created on Wed Jun 15 02:36:33 2022

@author: adminzhaoqian
"""
import dash
from dash import Dash, html, dcc, Input, Output, State
import plotly.express as px
import plotly.graph_objs as go

from InventoryModels import inventory

app = dash.Dash(meta_tags=[{
        'name': 'description',
        'content': 'An illustrative tool to showcase inventory prescriptive model capabilities.'},
        {'name': 'author',
         'content': 'Qian Zhao'}])
app.title = 'Inventory Simulator'
server = app.server

#-------------------------------
#Define Formatting Stuff
margin={'l':50, 'b':40, 'r':40, 't':40}
yaxis = dict(zeroline = False)
xaxis = dict(zeroline = False)

def graphingRegion(height, margin=margin):
        return {'data':[], 
                'layout': go.Layout(height=height, 
                                    margin=margin, 
                                    yaxis = dict(zeroline = False, showticklabels=False, showgrid=False),
                                    xaxis = dict(zeroline = False, showticklabels=False, showgrid=False),
                                    font=dict(family='Dosis')
                                    )
                }

intro_text = ''

app.layout = html.Div(
    html.Div([
        html.H3('Inventory Simulation Dashboard'),
        
        dcc.Interval(
            id='interval-component',
            interval=1*100, # in milliseconds
            n_intervals=0,
            max_intervals=600
        ), 
        html.Div(html.H6(id='animated-subtitle', children=' ', style={'line-height': '1.1', 'color': 'rgb(0, 153, 255)'})),
        
        html.Div([html.Div([html.H4('Enter Simulation Parameters:'), 
                            html.Button('Run Simulation', id='begin-simulation')], style={'width': '33%', 'display': 'inline-block'}), 
                  html.Div([html.Label('Enter List of Future Demand:'), 
                            dcc.Input(id='demand', type='number', step=1, placeholder='#Agents'),
                            html.Label('Enter Current Inventory Level:'), 
                            dcc.Input(id='iniven', type='number', step=1, placeholder='Intvl Call Avg')], style={'width': '33%', 'display': 'inline-block'}),
                  html.Div([html.Label('Enter Size of Onc Case/Lot:'), 
                            dcc.Input(id='lotsize', type='number', step=50, placeholder='AHT Min'),
                            html.Label('Enter Holding Cost:'), 
                            dcc.Input(id='holding', type='number', step=50, placeholder='AHT Max')], style={'width': '33%', 'display': 'inline-block'}),
                  html.Div([html.Label('Enter Fix Ordering Cost:'), 
                            dcc.Input(id='fix', type='number', step=1, placeholder='#Agents'),
                            html.Label('Enter Unit Cost:'), 
                            dcc.Input(id='unit', type='number', step=1, placeholder='Intvl Call Avg')], style={'width': '33%', 'display': 'inline-block'}),
                  html.Div([html.Label('Enter Initial Price:'), 
                            dcc.Input(id='iniprice', type='number', step=50, placeholder='AHT Min'),
                            html.Label('Enter Demand Elasticy of Price:'), 
                            dcc.Input(id='elasticy', type='number', step=50, placeholder='AHT Max')], style={'width': '33%', 'display': 'inline-block'})
                  ], style={'border': 'thin lightgrey solid', 'paddingLeft': '40', 'paddingBottom': '20', 'paddingTop': '10', 'backgroundColor': '', 'marginBottom': '5'}
                ),
                  
        html.Div(id='intro-text-above-graph', children=(dcc.Markdown(intro_text)), style={'backgroundColor': 'rgb(212,212,212,0.5)', 'padding': '10', 'marginTop': '1%'}),
        
        html.Div(id='graph-block', children=[
        #---
        #Call Count Graph
        html.Div([html.Div([dcc.Graph(id='live-update-graph', config={'displayModeBar': False}, figure=graphingRegion(450), clear_on_unhover=True, hoverData={'points':[{'customdata': 'showall'}]})], style={'width': '69%', 'display': 'inline-block'}),
                  html.Div(dcc.Markdown(id='simulation-details'), style={'width': '29%',  'fontSize': '80%', 'display': 'inline-block', 'verticalAlign': 'top', 'padding': '5', 'paddingTop': '10'})]),
            ])
        ])
    )

@app.callback([Output('lotsFigure', 'figure'), 
              Output('priceFigure', 'figure'),] 
              [Input('begin-simulation', 'n_clicks'),],
              [State('demand', 'value'), 
               State('iniven', 'value'), 
               State('lotsize', 'value'),
               State('holding', 'value'),
               State('fix', 'value'), 
               State('unit', 'value'), 
               State('iniprice', 'value'),
               State('elasticy', 'value'),]
              )
def gen_results(demand, iniven, lotsize, holding, fix, unit, iniprice, elasticy):
    
    demand = demand.split(',')
    iniven = iniven.split(',')

    ret = inventory.inventoryDefault(lotSize=lotsize,
                                    demand=demand,
                                    initInv=iniven,
                                    initPrice=iniprice,
                                    fixCost=fix,
                                    unitCost=unit,
                                    elastPD=elasticy,
                                    holdingCost=holding,
                                      )
    
    # fig1 = px.line(ret, x='date', y='order',)
    fig2 = px.bar(ret, x='date', y='lots',)
    fig3 = px.line(ret, x='date', y='price',)
    return fig2, fig3, 'Profit prediction: {}'.format(ret['profit'])


if __name__ == '__main__':
    app.run_server(debug=True, port='8051')