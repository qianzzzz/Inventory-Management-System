# -*- coding: utf-8 -*-
"""
Created on Wed May 18 07:48:46 2022

@author: adminzhaoqian
"""

# Run this app with `python app.py` and
# visit http://127.0.0.1:8050/ in your web browser.
import dash
from dash import Dash, html, dcc, Input, Output
import plotly.express as px
import plotly.graph_objs as go
import pandas as pd

from InventoryModels import inventory

app = Dash(__name__)

colors = {
    'background': '#111111',
    'text': '#7FDBFF'
}

# assume you have a "long-form" data frame
# # see https://plotly.com/python/px-arguments/ for more options
# df = pd.DataFrame({
#     "Fruit": ["Apples", "Oranges", "Bananas", "Apples", "Oranges", "Bananas"],
#     "Amount": [4, 1, 2, 2, 4, 5],
#     "City": ["SF", "SF", "SF", "Montreal", "Montreal", "Montreal"]
# })

# fig = px.bar(df, x="Fruit", y="Amount", color="City", barmode="group")

app.layout = html.Div(
                      children=[html.H1(children='Inventory Optimizer for Retail Store',
                                        style={'textAlign': 'center',
                                               'color': colors['text']
                                               }
                                        ),
    
                                html.H2(children='To visualize data flow', 
                                        style={'textAlign': 'center',
                                               'color': colors['text']
                                               }
                                        ),
    
                                html.Div(children='inventory optimization demonstration', 
                                         style={'textAlign': 'center',
                                                'color': colors['text']
                                                }
                                         ),
                                html.Br(),
                                html.Div(style={'display': 'flex', 'flex-direction': 'row'},
                                         children=[html.Div(children=[html.Div(children=[html.Label('Future Demand Input'),
                                                       dcc.Input(placeholder='37, 45, 88, 41, 75, 123, 72', type='text', value='37, 45, 88, 41, 75, 123, 72',
                                                                 id='demand')
                                                       ],
                                            style={'textAlign': 'left', 'padding': 10}
                                            ),
                                        
                                         html.Div(children=[html.Label('Initial Inventory Input'),
                                                       dcc.Input(placeholder='7, 4, 6, 0', type='text', value='7, 4, 6, 0',
                                                                 id='iniven'),
                                                       ],
                                            style={'textAlign': 'left', 'padding': 10}
                                             ),   
                                    
                                        html.Div(children=[html.Label('Lot Size Input'),
                                                       dcc.Input(placeholder=20, type='number', value=20,
                                                                 id='lotsize'),
                                                       ],
                                            style={'textAlign': 'left', 'padding': 10}
                                             ),   
                                    
                                        html.Div(children=[html.Label('Holding Cost Input'),
                                                       dcc.Input(placeholder=1, type='number', value=1,
                                                                 id='holding'),
                                                       ],
                                            style={'textAlign': 'left', 'padding': 10}
                                             ),   
                                        html.Div(children=[html.Label('Fix Ordering Cost Input'),
                                                       dcc.Input(placeholder=500, type='number', value=500,
                                                                 id='fix'),
                                                       ],
                                            style={'textAlign': 'left', 'padding': 10}
                                             ),   
                                        html.Div(children=[html.Label('Unit Cost Input'),
                                                       dcc.Input(placeholder=4, type='number', value=4,
                                                                 id='unit'),
                                                       ],
                                            style={'textAlign': 'left', 'padding': 10}
                                             ),   
                                        html.Div(children=[html.Label('Initial Price Input'),
                                                       dcc.Input(placeholder=10, type='number', value=10,
                                                                 id='iniprice'),
                                                       ],
                                            style={'textAlign': 'left', 'padding': 10}
                                             ),   
                                        html.Div(children=[html.Label('Demand Elasticy of Price Input'),
                                                       dcc.Input(placeholder=1.0, type='number', value=1.0,
                                                                 id='elasticy'),
                                                       ],
                                            style={'textAlign': 'left', 'padding': 10}
                                             ),]
                                    ),
                                # html.Br(),
                                html.Div(style={'display': 'flex', 'flex-direction': 'row'},
                                         children=html.Div(children=[

                                         html.Br(),
                                         dcc.Graph(id='demandG', 
                                                   style={'padding': 10, 'textAlign': 'right', 'flex':1,}),
                                         html.Br(),
                                         dcc.Graph(id='preint', 
                                                    style={ 'textAlign': 'right', 'flex':1,}),
                                         html.Br(),
                                         dcc.Graph(id='lotsFigure', 
                                                   style={'padding': 10, 'textAlign': 'right', 'flex':1,}),
                                         html.Br(),
                                         dcc.Graph(id='priceFigure', 
                                                   style={'padding': 10, 'textAlign': 'right', 'flex':1,}),
                                         # html.Br(),
                                         # dcc.Graph(id='closeInv', 
                                         #            style={ 'textAlign': 'right', 'flex':1,}),
                            ]
                                                           )
                                         ),
                                
                                html.Div(id='profit', style={'whiteSpace': 'pre-line', 'textAlign': 'left', }),
                                # html.Div(id='my-output', )
                                ])
                            ])

@app.callback(
    Output('lotsFigure', 'figure'), 
    Output('priceFigure', 'figure'), 
    Output('preint', 'figure'), 
    Output('demandG', 'figure'), 
    # Output('closeInv', 'figure'), 
    Output('profit', 'children'),
    Input('demand', 'value'),
    Input('iniven', 'value'),
    Input('lotsize', 'value'),
    Input('holding', 'value'),
    Input('fix', 'value'),
    Input('unit', 'value'),
    Input('iniprice', 'value'),
    Input('elasticy', 'value'),
    )
def update_output(demand, iniven, lotsize, holding, fix, unit, iniprice, elasticy):
    
    demand = demand.split(',')
    iniven = iniven.split(',')

    ret = inventory.inventoryDefault(lotSize=lotsize,
                                    demand=demand,
                                    initInv=iniven,
                                    initPrice=iniprice,
                                    fixCost=fix,
                                    unitCost=unit,
                                    elastPD=elasticy,
                                    holdingCost=holding,
                                      )
    # with open('E:\InventoryManagementPlatform\log3.txt', 'w') as f:
    #     f.write(str(ret))

    fig2 = px.bar(ret, x='date', y='lots', title='Order Case Quantity')
    fig3 = px.line(ret, x='date', y='price', title='Adjusted Price')
    # fig1 = px.bar(ret, x='date', y='preint',)
    
    # ret['preint'].insert(0, iniven)
    # _preintdate = ret['date'].insert(0, 'Before Planning')
    # preintdf = pd.DataFrame(ret['preint'], 
    #                         index=ret['date'],
    #                         columns=['fresh level {}'.format(i + 1) for i in range(len(ret['closeInv'][0]))])

    fig5 = px.bar(ret, x='date', y='demand', title='Induced Future Demand')
    
    df = pd.DataFrame(ret['closeInv'], 
                      columns=['fresh level {}'.format(i + 1) for i in range(len(ret['closeInv'][0]))], 
                      index=ret['date'])

    # res = []
    # for col in df.columns:
    #     res.append(
    #         go.Bar(
    #             x=df.index.values.tolist(),
    #             y=df[col].values.tolist(),
    #             name=col
    #         )
    #     )
    
    # layout = go.Layout(
    #     barmode='group',
    #     title='Close Inventory Level',
    # )

    # fig1 = go.Figure(data=res, layout=layout)    

    preint = []
    ret['preint'].insert(0, iniven)
    ret['date'].insert(0, 'day0')
    for i, lst in enumerate(ret['preint']):
        for j, quantity in enumerate(lst):
            preint.append({'date': ret['date'][i], 
                           'shelfLife': 'shelf life {} day(s)'.format(j + 1), 
                           'quantity': quantity})
    
    preintdf = pd.DataFrame(preint)
    
    fig4 = px.bar(preintdf, x='date', y='quantity', color='shelfLife', title='Previous Inventory Level')
    
    
    return fig2, fig4, fig5, fig3,  'Profit prediction: {}'.format(ret['profit'])

    # return fig1, fig2, fig3, 'Profit prediction: {}'.format(ret['profit'])
    # return f'1{ret}'ret['profit'],
    # return f'demand{demand[0]}, iniven{iniven[0]}, lotsize{lotsize}, holding{holding}, fix{fix},  iniprice{iniprice}, elasticy{elasticy},'

# app.run_server(debug=True)
if __name__ == '__main__':
    app.run_server(debug=True)